public class Player {
    private String name;
    private int points;

    // Constructor
    
    // Step 7
    public Player(){
      
    }


    public Player(String name) {
        this.name = name;
        this.points = 0;
    }

    // Accessors
    public String getName() {
        return name;
    }

    public int getPoints() {
        return points;
    }

    // Mutators
    public void setName(String name) {
        this.name = name;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public boolean guessLetter(char letter, String phrase) {
        if (phrase.indexOf(letter) != -1) {
            points += 100; // Assuming the points increase by 100 for every correct guess
            return true;
        }
        return false;
    }

    public boolean solvePuzzle(String guess, String phrase) {
        if (phrase.equals(guess)) {
            // Assuming the game ends when the puzzle is solved
            return true;
        }
        return false;
    }
}
