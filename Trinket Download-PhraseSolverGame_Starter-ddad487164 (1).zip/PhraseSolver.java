import java.util.Scanner;

public class PhraseSolver {
    private Board board;
    private Player player1;
    private Player player2;

    // Constructor
    //Step 7 
    public PhraseSolver(){
      
    }
    
    public PhraseSolver(String player1Name, String player2Name) {
        board = new Board();
        player1 = new Player(player1Name);
        player2 = new Player(player2Name);
    }

    // Accessors
    public Board getBoard() {
        return board;
    }

    public Player getPlayer1() {
        return player1;
    }

    public Player getPlayer2() {
        return player2;
    }

    // Mutators

    public void play() {
        boolean solved = false;
        int currentPlayer = 1;

        Scanner input = new Scanner(System.in);

        boolean correct = true;
        while (!solved) {

            System.out.println("Current Phrase: " + board.getSolvedPhrase());
            System.out.println("Current Letter Value: " + board.getCurrentLetterValue());

            Player currentPlayerObj = currentPlayer == 1 ? player1 : player2;

            System.out.print(currentPlayerObj.getName() + ", enter your guess: ");
            String guess = input.nextLine();

            if (guess.length() == 1) {
                boolean foundLetter = board.guessLetter(guess.charAt(0));
                if (foundLetter) {
                    System.out.println("Correct guess!");
                } else {
                    System.out.println("Incorrect guess!");
                }
            } else {
                boolean isSolved = board.isSolved(guess);
                if (isSolved) {
                    System.out.println("Congratulations! You solved the puzzle.");
                    solved = true;
                } else {
                    System.out.println("Incorrect guess! The game continues.");
                }
            }

            currentPlayer = currentPlayer == 1 ? 2 : 1;
        }
    }
}
